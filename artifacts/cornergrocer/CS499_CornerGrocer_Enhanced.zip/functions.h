/* Alexander Adams
* Corner Grocer Item Tracker
* Header File
*/

#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <iomanip>
#include <algorithm>
#include <vector>

using namespace std;

void displayMenu();
void countItemFrequency(const string& item, const map<string, int>& itemMap);
void displayAllItems(const map<string, int>& itemMap);
void displayHistogram(const map<string, int>& itemMap);
void createFrequencyFile(const map<string, int>& itemMap);
string convertToLower(string str);
string convertToUpper(string str);
// sorting + top items
void displaySortedItems(const map<string, int>& itemMap);
void displayTopItems(const map<string, int>& itemMap, int topN);

// menu handler
void handleUserChoices(const map<string, int>& itemMap);

#endif