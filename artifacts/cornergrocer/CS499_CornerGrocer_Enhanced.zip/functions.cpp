/* Alexander Adams
* Corner Grocer Item Tracker
* Function Definitions
*/

#include "functions.h"
#include <limits>

void displayMenu() {
    cout << "\nCorner Grocer Item Tracker\n";
    cout << "1. Search for an item\n";
    cout << "2. Display all items and their frequencies\n";
    cout << "3. Display histogram of item frequencies\n";
    cout << "4. Display items sorted by frequency\n";
    cout << "5. Display top purchased items\n";
    cout << "6. Exit\n";
}

void countItemFrequency(const string& item, const map<string, int>& itemMap) {
    auto it = itemMap.find(item);
    if (it != itemMap.end()) {
        cout << item << " was purchased " << it->second << " times." << endl;
    }
    else {
        cout << item << " was not found in the list." << endl;
    }
}

void displayAllItems(const map<string, int>& itemMap) {
    cout << "\nItem List:\n";
    for (const auto& pair : itemMap) {
        cout << setw(15) << left << pair.first << pair.second << endl;
    }
}

void displayHistogram(const map<string, int>& itemMap) {
    cout << "\nHistogram:\n";
    for (const auto& pair : itemMap) {
        // Uses '*' to visually represent frequency count
        cout << setw(15) << left << pair.first << string(pair.second, '*') << endl;
    }
}

void createFrequencyFile(const map<string, int>& itemMap) {
    ofstream outputFile("frequency.dat");
    if (!outputFile) {
        cout << "Error: Could not create backup file" << endl;
        return;
    }

    for (const auto& pair : itemMap) {
        outputFile << pair.first << " " << pair.second << endl;
    }

    outputFile.close();
}

string convertToLower(string str) {
    transform(str.begin(), str.end(), str.begin(), ::tolower);
    return str;
}

string convertToUpper(string str) {
    transform(str.begin(), str.end(), str.begin(), ::toupper);
    return str;
}

// Displays items sorted from highest to lowest frequency
void displaySortedItems(const map<string, int>& itemMap) {
    // Moved map data into vector so we can sort it
    vector<pair<string, int>> items(itemMap.begin(), itemMap.end());

    // Sort by frequency (second value)
    sort(items.begin(), items.end(), [](const pair<string, int>& a, const pair<string, int>& b) {
        return a.second > b.second;
    });

    cout << "\nItems sorted by frequency:\n";

    for (const auto& item : items) {
        cout << setw(15) << left << item.first << item.second << endl;
    }
}

// Displays top N most purchased items
void displayTopItems(const map<string, int>& itemMap, int topN) {

    // Prevent invalid input
    if (topN <= 0) {
        cout << "Invalid number. Please enter a positive value." << endl;
        return;
    }

    vector<pair<string, int>> items(itemMap.begin(), itemMap.end());

    sort(items.begin(), items.end(), [](const pair<string, int>& a, const pair<string, int>& b) {
        return a.second > b.second;
    });

    // Prevent going out of bounds
    if (topN > items.size()) {
        topN = items.size();
    }

    cout << "\nTop " << topN << " purchased items:\n";

    for (int i = 0; i < topN; i++) {
        cout << setw(15) << left << items[i].first << items[i].second << endl;
    }
}

// user menu interaction
void handleUserChoices(const map<string, int>& itemMap) {
    int choice;

    do {
        displayMenu();
        cout << "Enter your choice (1-6): ";

        // input validation
        while (!(cin >> choice)) {
            cout << "Invalid input. Please enter a number: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }

        switch (choice) {
        case 1: {
            string itemToFind;
            cout << "Enter the item you wish to find: ";
            cin >> itemToFind;
            itemToFind = convertToLower(itemToFind);
            itemToFind[0] = toupper(itemToFind[0]);
            countItemFrequency(itemToFind, itemMap);
            break;
        }
        case 2:
            displayAllItems(itemMap);
            break;
        case 3:
            displayHistogram(itemMap);
            break;
        case 4:
            displaySortedItems(itemMap);
            break;
        case 5: {
            int topN;
            cout << "Enter how many top items to display: ";
            cin >> topN;
            displayTopItems(itemMap, topN);
            break;
        }
        case 6:
            cout << "Exiting the program..." << endl;
            break;
        default:
            cout << "Invalid choice. Please try again." << endl;
        }

    } while (choice != 6);
}