/* Alexander Adams
* Corner Grocer Item Tracker
* This program reads a list of items purchased from Corner 
* Grocer store from an input file. It counts the frequency of 
* each item purchased and also generates backup file to store
* the frequency of each item.
*/

#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <iomanip> // Formatting output
#include <algorithm> // String transformation functions
#include "functions.h"

using namespace std;

int main() {
    // Stores each item and how many times it appears
    map<string, int> itemMap;
    string item;

    // Open input file
    ifstream inputFile("CS210_Project_Three_Input_File.txt");
    if (!inputFile) {
        cout << "Error: Could not open the input file!" << endl;
        return 1;
    }

    // Read each line, format, and count frequency
    while (getline(inputFile, item)) {
        item = convertToLower(item);
        item[0] = toupper(item[0]); // consistent formatting
        itemMap[item]++;
    }

    inputFile.close(); // Close file

    // Create backup frequency.dat file
    createFrequencyFile(itemMap);

    // Handle menu choices
    handleUserChoices(itemMap);

    return 0;
}