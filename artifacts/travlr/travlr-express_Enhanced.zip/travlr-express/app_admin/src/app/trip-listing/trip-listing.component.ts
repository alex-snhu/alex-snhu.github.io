import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { TripCardComponent } from '../trip-card/trip-card.component';
import { TripDataService } from '../services/trip-data.service';
import { Trip } from '../models/trip';

import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [CommonModule, TripCardComponent, FormsModule],
  templateUrl: './trip-listing.component.html',
  styleUrl: './trip-listing.component.css',
  providers: [TripDataService]
})
export class TripListingComponent implements OnInit {

  trips: Trip[] = [];
  message: string = '';

  // stores what user types in search box
  searchTerm: string = '';

  constructor(
    private tripDataService: TripDataService,
    private router: Router,
    private authenticationService: AuthenticationService
  ) {
    console.log('trip-listing constructor');
  }

  public addTrip(): void {
    this.router.navigate(['add-trip']);
  }

  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  // gets trips (all OR filtered)
  private getStuff(): void {
    this.tripDataService.getTrips(this.searchTerm)
      .subscribe({
        next: (value: any) => {
          console.log('TRIPS FROM API:', value);
          this.trips = value;

          if (value.length === 1) {
            this.message = 'There is 1 trip available.';
          } else if (value.length > 1) {
            this.message = 'There are ' + value.length + ' trips available.';
          } else {
            this.message = 'No trips match your search.';
          }

          console.log(this.message);
        },
        error: (error: any) => {
          console.log('Error: ' + error);
        }
      });
  }

  // runs when search button is clicked
  public onSearch(): void {
    this.getStuff();
  }

  ngOnInit(): void {
    console.log('ngOnInit');
    this.getStuff();
  }
}