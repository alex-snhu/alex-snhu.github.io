from pymongo import MongoClient

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self):
        DB = 'AAC'
        COL = 'animals'

        # connect to local MongoDB
        self.client = MongoClient('mongodb://localhost:27017')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        if data:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print("Insert failed:", e)
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    def read(self, query):
        try:
            return list(self.collection.find(query))
        except Exception as e:
            print("Read failed:", e)
            return []

    def update(self, query, new_values):
        try:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        except Exception as e:
            print("Update failed:", e)
            return 0

    def delete(self, query):
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print("Delete failed:", e)
            return 0